# CubeSoftware

Para rodar a página no seu computador:

1 - Instale o VCREDIST 2015 (x64):

https://www.microsoft.com/en-us/download/details.aspx?id=48145&fa43d42b-25b5-4a42-fe9b-1634f450f5ee=True

2 - Instale o WAMP (x64)
https://sourceforge.net/projects/wampserver/files/WampServer%203/WampServer%203.0.0/wampserver3_x64_apache2.4.17_mysql5.7.9_php5.6.16_php7.0.0.exe/download

2 - Crie uma pasta em c:\wamp64\www e coloque todos os arquivos da branch lá (ex. c:\wamp64\www\cuberep).

3 - Execute o programa Wampserver64

4 - No navegador, digite localhost/nome-da-pasta/nome-do-arquivo (ex. localhost/cuberep/admin.php)
